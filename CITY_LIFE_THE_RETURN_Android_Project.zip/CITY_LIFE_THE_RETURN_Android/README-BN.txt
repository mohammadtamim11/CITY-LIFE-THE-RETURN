CITY LIFE: THE RETURN — Android APK Build Project
ভার্সন: 0.4

এই ZIP-এ আপনার আপলোড করা index-5.html গেমটি Android WebView অ্যাপের মধ্যে রাখা হয়েছে।
অ্যাপের নাম: CITY LIFE: THE RETURN
Package: com.citylife.thereturn
Orientation: Landscape
Offline: হ্যাঁ (গেমের HTML লোকাল assets থেকে খোলে)

APK বানানোর সহজ উপায় (Android ফোন দিয়েও):
1. ZIP ফাইলটি GitHub-এ একটি নতুন repository-তে আপলোড করুন।
2. Repository-এর Actions ট্যাবে যান।
3. "Build CITY LIFE APK" workflow খুলুন।
4. Run workflow চাপুন।
5. Build শেষ হলে CITY-LIFE-THE-RETURN-APK artifact ডাউনলোড করুন।
6. ZIP artifact Extract করে app-debug.apk ইনস্টল করুন।
   Android Settings-এ "Install unknown apps" অনুমতি দিতে হতে পারে।

গুরুত্বপূর্ণ:
- এই পরিবেশে Android SDK/Gradle build toolchain নেই, তাই এখানে APK compile করা হয়নি।
- GitHub Actions workflow দিয়ে ক্লাউডে APK build করার জন্য project প্রস্তুত।
- প্রথমবার build করতে GitHub account ও internet প্রয়োজন।
- APK ইনস্টল করার আগে Android Play Protect সতর্কতা দেখাতে পারে; নিজের তৈরি/বিশ্বস্ত build হলেই install করবেন।
